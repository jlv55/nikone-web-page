$(function() {

        $('#header').parallax("50%", 0.3);
        $('#videosPromo').parallax("50%", 0.3);


    $('#showdiv1').click(function() {
        $('div[id^=div]').hide();
        $('#div1').show();
    });
    $('#showdiv2').click(function() {
        $('div[id^=div]').hide();
        $('#div2').show();
    });
    $('#showdiv3').click(function() {
        $('div[id^=div]').hide();
        $('#div3').show();
    });
    $('#showdiv4').click(function() {
        $('div[id^=div]').hide();
        $('#div4').show();
    });
    $('#showdiv5').click(function() {
        $('div[id^=div]').hide();
        $('#div5').show();
    });
    $('#showdiv6').click(function() {
        $('div[id^=div]').hide();
        $('#div6').show();
    });
    $('#showdiv7').click(function() {
        $('div[id^=div]').hide();
        $('#div7').show();
    });
    $('#showdiv8').click(function() {
        $('div[id^=div]').hide();
        $('#div8').show();
    });
})
